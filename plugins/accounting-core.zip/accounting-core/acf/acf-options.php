<?php
add_action( 'acf/init', 'my_acf_op_init' );
function my_acf_op_init() {

	// Check function exists.
	if ( function_exists( 'acf_add_options_page' ) ) {

		acf_add_options_page( array(
			'page_title' => __( 'Theme Settings', 'accounting' ),
			'menu_title' => __( 'Theme Settings', 'accounting' ),
			'menu_slug'  => 'theme-settings',
			'capability' => 'edit_posts',
			'redirect'   => true
		) );

		acf_add_options_sub_page( array(
			'page_title'  => __( 'Header', 'accounting' ),
			'menu_title'  => __( 'Header', 'accounting' ),
			'parent_slug' => 'theme-settings',
		) );
		acf_add_options_sub_page( array(
			'page_title'  => __( 'Home Page', 'accounting' ),
			'menu_title'  => __( 'Home Page', 'accounting' ),
			'parent_slug' => 'theme-settings',
		) );
		acf_add_options_sub_page( array(
			'page_title'  => __( 'Breadcrumb', 'accounting' ),
			'menu_title'  => __( 'Breadcrumb', 'accounting' ),
			'parent_slug' => 'theme-settings',
		) );
		acf_add_options_sub_page( array(
			'page_title'  => __( 'Contact Page', 'accounting' ),
			'menu_title'  => __( 'Contact Page', 'accounting' ),
			'parent_slug' => 'theme-settings',
		) );

		acf_add_options_sub_page( array(
			'page_title'  => __( 'Footer', 'accounting' ),
			'menu_title'  => __( 'Footer', 'accounting' ),
			'parent_slug' => 'theme-settings',
		) );
	}
}