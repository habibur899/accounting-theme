<?php
/**
 * Plugin Name:       Accounting Core
 * Plugin URI:        https://github.com/habibur899/accounting-core
 * Description:       This is a companion plugin for accounting theme
 * Version:           1.0.0
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            Habibur Rahaman
 * Author URI:        https://github.com/habibur899
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       accounting
 * Domain Path:       /languages
 */
require_once plugin_dir_path(__FILE__).'/acf/acf-options.php';
require_once plugin_dir_path(__FILE__).'/acf/acf-setting.php';